package com.sga;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
